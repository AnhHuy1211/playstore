﻿<?php
	require_once('xuly.php');
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<title>Hướng dẫn upload ảnh - Lập Trình Việt Nhật</title>
</head>
	<body>
		<form action="" enctype="multipart/form-data" method="POST">
		   Chọn file ảnh: <input type="file" name="uploadFile"><br>
		   <input type="submit" name="submit" value="Upload">
		</form>
	</body>
</html>
