<?php
include_once './config.php';
session_start();
$conn = openDB();
$gameid = $_GET['gameid'];
$sql="select * from all_game_not_free where gameid='$gameid'";
$result = mysqli_query($conn, $sql);
$gamename='';
$des ='';
$des_extra = '';
$name_author = '';
$money = '';
if (mysqli_num_rows($result) > 0) {
    while ($row = $result->fetch_assoc()) {
        $gamename = $row['gamename'];
        $des = $row['description'];
        $des_extra = $row['description_extra'];
        $name_author = $row['name_author'];
        $money = $row['game_money'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/1f93e99ed1.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="main.js"></script>
</head>
<body>
<div class="header">
    <div class="row">
        <div class="col-lg-9">
            <a href="index.php">
					<img class="logo" src="./pictures/logo.png" alt="logo">
				</a>
            <a>
                <input class="search-box" type="text" placeholder="Tìm kiếm">
                <button class="search-button" type="submit"><i class="fa fa-search"></i>
                </button>
            </a>
        </div>
        <div class="col-lg-2">
            <?php
            if (isset($_SESSION['user'])){
                echo "<p class='stylechao'>Xin chào, ".$_SESSION['name']."</p>";
                echo '<a href="logout.php"><button class="loginn" type="submit">Đăng xuất</button></a>';
            } else {
                echo '<a href="login.php"><button class="login" type="submit">Đăng nhập</button></a>';
            }
            ?>
        </div>
    </div>
</div>
<div>
    <div>
        <ul>
			<li><a class="apps-trochoi" href="game_info.php"><button class="but" disabled="disabled"><i class="fas fa-th-large"></button></i>  Trò chơi</a></li>
	  		<li><a class="home-trochoi" href="index.php"><button class="bbt" disabled="disabled"><i class="fas fa-house-user"></button></i>  Trang chủ</a></li>
	  		<li><a class="movie" href="movie_info.php"><button class="butt" disabled="disabled"><i class="fas fa-video"></button></i>  Phim</a></li>
	  		<li><a class="account" href="taikhoan.php"><button class="buutt" disabled="disabled"><i class="fas fa-user-circle"></button></i>  Tài khoản</a></li>
			<li><a class="cash" href="naptien.php"><button class="buttt" disabled="disabled"><i class="fas fa-money-check"></button></i>  Nạp tiền</a></li>	
		</ul>

        <div class="genshin-main">
            <div class="row">
                <div class="col-sm-4">
                    <img src="./pictures/genshin.png">
                </div>
                <div class="col-sm-8">
                    <h2><span class="app-title"><?= $gamename?> </span></h2>
                    <span class="app-name"><?= $name_author?></span>
                    <span class="app-rate">
		                    <i class="fa fa-star"></i>
		                  	<i class="fa fa-star"></i>
		                    <i class="fa fa-star"></i>
		                    <i class="fa fa-star"></i>
		                    <i class="fa fa-star-half-empty"></i>
		                    <i>1.001.121</i>
		                    <i class="fa fa-user"></i>
		                    <span class="money"><?= $money?></span>
		                </span>
                    <button class="btn">
                        <?php
                        $uid = uniqid();
                        ?>
                        <a href="download.php?fileId=<?= $uid ?>"><i class="fa fa-download"></i>
                            Tải</a>
                    </button>

                </div>
            </div>

            <div>
                <div id="demo" class="img_slide carousel slide" data-ride="carousel">
                    <ul class="carousel-indicators">
                        <li data-target="#demo" data-slide-to="0" class="active"></li>
                        <li data-target="#demo" data-slide-to="1"></li>
                        <li data-target="#demo" data-slide-to="2"></li>
                    </ul>
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="./pictures/gen1.jpg" />
                        </div>
                        <div class=" carousel-item ">
                            <img src="./pictures/gen2.jpg" />
                        </div>
                        <div class="carousel-item">
                            <img src="./pictures/gen3.jpg" />
                        </div>
                    </div>
                    <a class="carousel-control-prev" href="#demo" data-slide="prev">
                        <span class="carousel-control-prev-icon"></span>
                    </a>
                    <a class="carousel-control-next" href="#demo" data-slide="next">
                        <span class="carousel-control-next-icon"></span>
                    </a>
                </div>
            </div>
            <div class="nd">
                <p class="noidung"><?= $des?><br></p>
                <button aria-expanded="false" class="btn btn-primary" id="button" data-toggle="collapse" data-target="#docthem" >Đọc thêm</button>
                <div class="collapse mt-4" id="docthem">
                    <p class="noidung"><?= $des_extra?></p>
                </div>
                <div class="comment">
                    <h3>Bình luận</h3>
                    <form role="form">
                        <div class="form-group">
                            <textarea class="form-control" rows="2"></textarea>
                        </div>
                        <button type="submit" class="btn btn-success">Đăng</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>