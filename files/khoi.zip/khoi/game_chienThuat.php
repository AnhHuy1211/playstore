<?php
include_once './config.php';
session_start();
$conn = openDB();
$sql="select * from all_game_free";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://kit.fontawesome.com/1f93e99ed1.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="main.js"></script>
</head>
<body>
<div class="header">
    <div class="row">
        <div class="col-lg-9">
            <a href="index.php">
                <img class="logo" src="./pictures/logo.png" alt="logo">
            </a>
            <a>
                <input class="search-box" type="text" placeholder="Tìm kiếm">
                <button class="search-button" type="submit"><i class="fa fa-search"></i>
                </button>
            </a>
        </div>
        <div class="col-lg-2">
            <?php
            if (isset($_SESSION['user'])){
                echo "<p class='stylechao'>Xin chào, ".$_SESSION['name']."</p>";
                echo '<a href="logout.php"><button class="loginn" type="submit">Đăng xuất</button></a>';
            } else {
                echo '<a href="login.php"><button class="login" type="submit">Đăng nhập</button></a>';
            }
            ?>
        </div>
    </div>
</div>
<div>
    <div>
        <ul>
			<li><a class="apps-trochoi" href="game_info.php"><button class="but" disabled="disabled"><i class="fas fa-th-large"></button></i>  Trò chơi</a></li>
	  		<li><a class="home-trochoi" href="index.php"><button class="bbt" disabled="disabled"><i class="fas fa-house-user"></button></i>  Trang chủ</a></li>
	  		<li><a class="movie" href="movie_info.php"><button class="butt" disabled="disabled"><i class="fas fa-video"></button></i>  Phim</a></li>
	  		<li><a class="account" href="taikhoan.php"><button class="buutt" disabled="disabled"><i class="fas fa-user-circle"></button></i>  Tài khoản</a></li>
			<li><a class="cash" href="naptien.php"><button class="buttt" disabled="disabled"><i class="fas fa-money-check"></button></i>  Nạp tiền</a></li>	
		</ul>
        <div class="main">
            <div class="dropdown">
                <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
                    Thể loại
                </button>
                <div class="dropdown-menu">
                    <a class="dropdown-item" href="game_chienThuat.php">Chiến Thuật</a>
                    <a class="dropdown-item" href="game_tuDuy.php">Tư Duy</a>
                </div>
            </div>
            <h1><a href="game_info.php">Game Chiến Thuật dùng bộ não mánh khóe.</a></h1>
            <div class="row">
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="col-xl-2 col-lg-3 col-md-4 col-sm-6 col-12">
	                	<div class="game">
		                    <a href="./all_game_free.php?gameid='.$row['gameid'].'">
		                    	<img src="./pictures/genshin.png">
		                    </a>
		                    <div class="game-information">
		                        <span class="game-title"><a href="./all_game_free.php?gameid='.$row['gameid'].'">'.$row['gamename'].'</a></span>
		                        <span class="game-author"><a href="./all_game_free.php?gameid='.$row['gameid'].'">'.$row['name_author'].'</a></span>
		                        <span class="game-rate">
		                        	<i class="fa fa-star"></i>
		                        	<i class="fa fa-star"></i>
		                        	<i class="fa fa-star"></i>
		                        	<i class="fa fa-star"></i>
		                        	<i class="fa fa-star-half-empty"></i>
		                        </span>
		                        <span class="money"><a href="./all_game_free.php?gameid='.$row['gameid'].'">'.$row['game_money'].'</a></span>
		                    </div>
	                	</div>
	            	</div>';
                    }
                }
                ?>
            </div>