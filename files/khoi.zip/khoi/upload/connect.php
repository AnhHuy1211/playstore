<?php
$host = 'localhost'; // 127.0.0.1
$user = 'root';
$password = '';
$database = 'gallery';
$connect = mysqli_connect($host, $user, $password, $database) or die('Not connect');
date_default_timezone_set("Asia/Bangkok");
?>