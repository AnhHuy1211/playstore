<?php
    $Cname[] = "Angry Bird";
    $Cname[] = "Score 2";
    $Cname[] = "Genshin Impact";
    $Cname[] = "Dragon City";
    $Cname[] = "Lien Quan";
    $Cname[] = "Mulan";
    $Cname[] = "Tenet";
    $Cname[] = "Soul";
    $Cname[] = "Rampage";
    $Cname[] = "Sonic";
    $Cname[] = "Godzilla";
    $Cname[] = "Golf";


$input = $_REQUEST["country"];

$hint = "";

if ($input !== "") {
    $input = strtolower($input);
    foreach($Cname as $country) {
        if (stristr($input, substr($country, 0, strlen($input)))) {
            if ($hint === "") {
                $hint = "<li class=\"list-group-item\">".$country."</li>";
            } else {
                $hint .= "<li class=\"list-group-item\">".$country."</li>";
            }
        }
    }
}

echo "<a href='exercise3.php'>".$hint."</a";
?>
