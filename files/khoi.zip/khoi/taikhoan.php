<?php
session_start();
require_once('db.php');

$ss_user = $_SESSION['user'];
$sql = "select * from account where username = '$ss_user'";

$conn = open_database();

$ldata = mysqli_query($conn,$sql);
$email='';
$first = '';
$last='';
$pass='';
$user='';
if (mysqli_num_rows($ldata) > 0) {
    while ($row = $ldata->fetch_assoc()) {

        $email=$row['email'];
        $user= $row['username'];
        $first = $row['firstname'];
        $last = $row['lastname'];
        $pass = $row['password'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/1f93e99ed1.js" crossorigin="anonymous"></script>
  	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  	<link rel="stylesheet" type="text/css" href="style.css">
  	<script src="main.js"></script>
</head>
<body>
	<div class="header">
		<div class="row">
			<div class="col-lg-9">
                <a href="index.php">
					<img class="logo" src="./pictures/logo.png" alt="logo">
				</a>
				<a>
			    <input class="search-box" type="text" placeholder="Tìm kiếm">
			    <button class="search-button" type="submit">
			    	<i class="fa fa-search"></i>
				</button>
				</a>
			</div>
			<div class="col-lg-2">
                <?php
                    if (isset($_SESSION['user'])){
                        echo "<p class='stylechao'>Xin chào, ".$_SESSION['name']."</p>";
                        echo '<a href="logout.php"><button class="loginn" type="submit">Đăng xuất</button></a>';
                    } else { 
                        echo '<a href="login.php"><button class="login" type="submit">Đăng nhập</button></a>';
                    }
                ?>
			</div>
		</div>
	</div>
	<div class="body">
		<div>
            <ul>
                <li><a class="account-taikhoan" href="taikhoan.php"><button class="buutt" disabled="disabled"><i class="fas fa-user-circle"></button></i>  Tài khoản</a></li>
  				<li><a class="home-taikhoan" href="index.php"><button class="bbt" disabled="disabled"><i class="fas fa-house-user"></button></i>  Trang chủ</a></li>
                <li><a class="apps" href="game_info.php"><button class="but" disabled="disabled"><i class="fas fa-th-large"></button></i>  Trò chơi</a></li>
  				<li><a class="movie" href="movie_info.php"><button class="butt" disabled="disabled"><i class="fas fa-video"></button></i>  Phim</a></li>
	  			<li><a class="cash" href="naptien.php"><button class="buttt" disabled="disabled"><i class="fas fa-money-check"></button></i>  Nạp tiền</a></li>
			</ul>
            <?php
            if(isset($_SESSION['user'])) {
                ?>
                <div class="main">
                    <h1>Cập Nhật Thông Tin Cá Nhân</h1>
                    <form class="form_user" method="post" action="./taikhoan.php">
                        <div class="form-group">
                            <label for="username">Họ:</label>
                            <div ><input type="text" id="username" name="first" value="<?=$first?>"></div>
                        </div>
                        <div class="form-group">
                            <label for="username">Tên:</label>
                            <div><input type="text" id="username" name="last"value="<?=$last?>"></div>
                        </div>
                        <div class="form-group">
                            <label for="password">Đổi mật khẩu:</label>
                            <div ><input type="password" id="password" name="password"></div>
                        </div>
                        <p>Cập nhật ảnh đại diện.</p>
                        <span>Tải ảnh của bạn. </span>
                        <input type="file" id="myFile" name="filename">
                        <br>
                        <input type="submit" name="submit" value="Gửi">
                        <?php
                        if (!empty($error)) {
                            echo "<div class='alert alert-danger'>$error</div>";
                        }
                        if(isset($_POST['submit'])) {
                            change_name($email, $_POST['first'], $_POST['last']);
                            $first = $_POST['first'];
                                $last =$_POST['last'];
                            $_SESSION['name']= $_POST['first']." ".$_POST['last'];
                            if(strlen($_POST['password']) != 0) {
                                change_Password($_POST['password'], $email);
                            }
                        }
                        ?>
                    </form>
                </div>
                <?php
            }
            ?>
		</div>
	</div>
</body>
</html>