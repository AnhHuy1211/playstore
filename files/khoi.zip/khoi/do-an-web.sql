-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2021 at 09:36 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `do-an-web`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `username` varchar(250) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `activate_token` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`username`, `firstname`, `lastname`, `email`, `password`, `activate_token`) VALUES
('qane', '0', 'Nguyen', 'quynhanhaww@gmail.com', '$2y$10$w2oWoHqRGs416mRKYGkx/eLNqGMd1j.0lRcXfSvLIpQHFIbkzHvku', '3f4e34e5ad7a7efdabc9dbc9b6e84e21'),
('123123', 'quynhanh', 'Nguyen', 'leenana17072k1@gmail.com', '$2y$10$GyZXN.j/z6LQkfD1YXtMeO9tkr2BYuEDqdrMsjqI5G9pFsuSnXAYm', 'a451974ee195279262845bfe44e4a004'),
('qane', 'quynhanhnguyen', 'Nguyenhuynh', '51900645@student.tdtu.edu.vn', '$2y$10$aROdJz5scHLFCZC3Jx5l0.Qkz7UTzjdX58kYCL72//bmrwZ0J7SiG', '0c01d03679fd65c77275119745d6e388'),
('anhhuy', 'anhhuy', 'huy', 'nguyen.a.huy03217@gmail.com', '$2y$10$BB5OxV7MMCQgZRDKvvI9yezmLpbx.CpAk.TDNe4md7SGoOoHweBbi', 'fa686d3bcb589b939569e09158689aa8');

-- --------------------------------------------------------

--
-- Table structure for table `all_game`
--

CREATE TABLE `all_game` (
  `gameid` varchar(20) NOT NULL,
  `gamename` varchar(100) NOT NULL,
  `name_author` longtext NOT NULL,
  `game_money` longtext NOT NULL,
  `description` longtext NOT NULL,
  `description_extra` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `all_game`
--

INSERT INTO `all_game` (`gameid`, `gamename`, `name_author`, `game_money`, `description`, `description_extra`) VALUES
('game001', 'Genshin Impact-S.PAY', 'MiHoYo Limited', '10.000 ₫', 'Lục địa Teyvat rộng lớn, nơi vô số sinh vật sinh sôi và hội tụ.\r\n							Đấy là thế giới do bảy vị Thần thống trị, cũng là nơi bảy loại nguyên tố tụ hội...', 'Dưới bầu trời xa lạ, có người thiếu niên và thiếu nữ đang đứng trong gió bụi.\r\n							Các bạn chính là cặp song sinh đến từ vùng đất xa lạ. Người thân của bạn bị vị Thần lạ mặt bắt đi, và bạn cũng bị Thần phong ấn chìm vào giấc ngủ sâu...\r\n							Genshin Impact là một game nhập vai phiêu lưu thế giới mở mới được phát triển bởi miHoYo. Bạn sẽ khám phá một thế giới giả tưởng có tên là \"Lục địa Teyvat\" trong trò chơi.\r\n							Trong thế giới rộng lớn này, bạn có thể du hành qua bảy vương quốc, gặp gỡ những người bạn đồng hành với những tính cách và năng lực độc đáo khác nhau, cùng chiến đấu chống lại kẻ thù mạnh và bước vào con đường tìm kiếm người thân, hoặc bạn có thể đi lang thang không mục đích và đắm mình trong một thế giới đầy sức sống. Hãy để sự tò mò thúc đẩy bản thân khám phá mọi bí mật trong thế giới này nào...\r\n							Cho đến khi bạn đoàn tụ với người thân và chứng kiến sự lắng đọng của mọi thứ ở điểm đến cuối cùng.\r\n							〓Thế giới mở, tự do khám phá〓\r\n							Genshin Impact là một game nhập vai phiêu lưu thế giới mở, chỉ cần bạn sử dụng thể lực hợp lý, thì sẽ có thể chu du đến mọi vùng núi cao biển rộng, khám phá những cảnh vật kỳ bí. Hãy cùng nhau thám hiểm xem sẽ có những gì đang đợi bạn phía trước nào!\r\n\r\n							〓Phản ứng nguyên tố, chiến đấu chiến lược〓\r\n							Thế giới trong game được hình thành bởi bảy loại nguyên tố: Phong, Lôi, Thủy, Hỏa, Băng, Thảo, Nham. Nhân vật có Vision sẽ có thể dùng sức mạnh của nguyên tố để chiến đấu và thám hiểm. Thủy gặp Hỏa sẽ bốc hơi, Hỏa gặp Lôi sẽ quá tải, Lôi gặp Thủy sẽ nhiễm điện... Đối mặt với kẻ địch khác nhau, có thể dùng kỹ năng khác nhau để kích hoạt nguyên tố khắc chế giành chiến thắng.\r\n\r\n							〓Đồ họa và âm nhạc chất lượng cao〓\r\n							Genshin Impact có phong cách nghệ thuật mới mẻ, chuyển động của nhân vật được thực hiện thông qua việc nắm bắt cử động và điều chỉnh chi tiết, mang đến hiệu ứng trình diễn chất lượng cao. Ngày đêm thay đổi 24 giờ, thời tiết và âm nhạc cũng thay đổi linh hoạt, dù bạn ở đâu, bạn cũng sẽ luôn nghe thấy những màn trình diễn đặc trưng của dàn nhạc giao hưởng hàng đầu thế giới như London Philharmonic Orchestra và Shanghai Symphony Orchestra.\r\n\r\n							〓Tập hợp đồng đội, cùng nhau thám hiểm\r\n							Trong quá trình thám hiểm, còn có thể kết giao được với những đồng đội có khả năng đặc biệt, hãy thử kết hợp đội hình mạnh nhất, thu thập nguyên liệu cường hóa nhân vật để chinh phục bí cảnh nào. Rất nhiều điều mới mẻ đang chờ bạn khám phá, cùng bắt đầu thôi nào.\r\n						\r\n							Genshin Impact khu vực Việt Nam được phát hành độc quyền bởi Công ty cổ phần dịch vụ S.PAY Việt Nam.\r\n						'),
('game002', 'Golf', 'Haegin Co., Ltd.', '5.000 ₫', 'Enough with the boring golf games! Time for some 	thrilling excitement without the wait!<br>\r\n						Enjoy the fast and easy golf battle with maximum of 8 players!\r\n					\r\n						Are you ready to hit the green at EXTREME GOLF?', '● Real-time Multiplayer Golf Battle\r\n						- A fast-paced real-time round of golf where you don\'t have to wait for others!\r\n						- Hit the green with golfers around the world through instant matchmaking!\r\n						- Rise up the ranks and become the king of golf!\r\n						\r\n						● Simple Controls! Nothing could be easier! Easy and swift matches!\r\n						- Aim! Swing! It\'s that easy! Find the optimal direction and power. Then, simply pull and let go and to land your ball on the fairway!\r\n						- Golf and life is all about the timing! Pull and let go at the perfect timing for the perfect putt.\r\n						- Don\'t worry if you are new to golf. With these simple controls, hitting a Birdie, Albatross, or a Hole-In-One won\'t only be a dream!\r\n						\r\n						● Golf clubs and balls are your best friends on the field!\r\n						- Drivers, Woods, Long Irons, Short Irons, Rough Irons, Wedges, Sand Wedges, and Putters. We\'ve got everything you need!\r\n					    - Master the beautiful Courses with various Clubs and unique Balls!\r\n						- Build your very own Club by upgrading its Power, Accuracy, Top Spin, Back Spin, etc.!\r\n						- Improve your Club to perfection through Club Fitting!'),
('game003', 'Angry Birds', 'Entertainment', '0 ₫', 'Tham gia cùng hàng trăm triệu người chơi MIỄN PHÍ và bắt đầu cuộc phiêu lưu thú vị với súng cao su ngay bây giờ! Lập nhóm với bạn bè của bạn, leo lên bảng xếp hạng, tập hợp trong gia tộc, thu thập mũ, tham gia các thử thách và chơi các sự kiện vui nhộn trong các chế độ chơi hoàn toàn mới. Phát triển nhóm của bạn và thể hiện kỹ năng của bạn trong trò chơi Angry Birds thú vị nhất hiện có!', '● THỬ THÁCH HÀNG NGÀY. Có một phút? Hoàn thành thử thách hàng ngày và kiếm một số phần thưởng nhanh chóng.\r\n● LÊN CẤP cho nhân vật của bạn bằng lông vũ và tăng sức mạnh ghi điểm của họ. Xây dựng đàn cuối cùng!\r\n● THAM GIA CLAN để hạ gục những con lợn với bạn bè và người chơi trên khắp thế giới.\r\n● CẠNH TRANH trong ARENA. Cạnh tranh với những người chơi khác để có một số niềm vui thả chim thân thiện và chứng minh ai là người giỏi nhất.\r\n● THU SILLY HATS. Thu thập những chiếc mũ với các chủ đề vui nhộn khác nhau để nâng cấp trò chơi thời trang cho đàn của bạn và tham gia các sự kiện đặc biệt.\r\n● HÃY ẤN TƯỢNG THE MIGHTY EAGLE trong những thử thách đặc biệt trong Mighty Eagle’s Bootcamp và kiếm tiền để sử dụng trong cửa hàng độc quyền của anh ấy.\r\n● RẤT NHIỀU MỨC. Chơi hàng trăm cấp độ với nhiều hơn được bổ sung trong các bản cập nhật thường xuyên và các sự kiện trong thời gian giới hạn.\r\n● BẢNG LÃNH ĐẠO. Cạnh tranh với bạn bè của bạn và những người chơi khác và chứng minh ai là người giỏi nhất trên bảng xếp hạng toàn cầu.\r\n● CHỌN CON CỦA BẠN. Chọn con chim nào để đưa vào súng cao su và đánh bại những con lợn bằng chiến lược!\r\n● MỨC NHIỀU GIAI ĐOẠN. Chơi các cấp độ thú vị, đầy thử thách với nhiều màn chơi - chỉ cần chú ý đến Boss Pigs!'),
('game004', 'Score 2', 'First Touch', '0 ₫', 'A NEW HERO! The brand new sequel to the award winning, chart topping, mobile smash hit!\r\n\r\nYou are unknown but your potential is extraordinary. You know your talents must be released for the world to see! Unleash your Hero on a glittering career by shooting, passing and scoring your way to superstardom!', 'Incredible graphics, showcasing glorious animations and hyper-realistic gameplay! Now with officially licensed, REAL clubs and leagues! Authentic kits and badges give the ultimate soccer experience! You\'ll be at the heart of the action as you guide your Hero from hot prospect to global superstar!\r\n\r\nThis is a soccer sequel like no other for a game that is like no other!!!\r\n\r\nFEATURES\r\n• REVEL in an exciting new story following your Hero\'s soccer career!\r\n• SCORE amazing goals, PICK out that killer pass and CURL your screaming shots into the top corner!\r\n• PACKED with over 90 officially licensed teams from some of the world\'s greatest leagues! Who will you sign for?\r\n• ENHANCED graphics, ENRICHED motion-captured animations and with the same instantly recognisable \"pick-up and go\" gameplay\r\n• BRAND NEW Infinite Hero mode, How far will you go?\r\n• INSTANTLY RECOGNISABLE commentary from one of the world\'s top commentators, ARLO WHITE!!\r\n• HAND-PICK your Hero\'s unique look and customise his appearance.\r\n• TRIUMPH WITH TROPHIES as you progress through your career and unlock great prizes!\r\n• CONNECT to Facebook to sync your progress across devices\r\n\r\nTake your chances, score the goals, be the HERO!'),
('game005', 'Dragon City', 'Socialpoint', '1.000 ₫', 'Ready to take on the hottest dragon game and collect and breed tons of adorable fire-breathing dragons? Train them to your will, grow your collection, build your city, and prove your might to be the top Dragon Master in the world!', 'Build a Dragon City on floating islands, fill it with farms, habitats, buildings…and tons of dragons! Breed cute, baby dragons, treat them well and build farms to feed and evolve them into stunning monsters to expand your collection and battle them in the game’s PvP Arenas!\r\n\r\nJoin forces with other Dragon Masters in the game by joining an Alliance! Interact in the chat, participate in Alliance events, trade Orbs, and unlock special rewards.\r\n\r\nCombine dragons of Fire, Nature, Pure, Legend, and many other elements, to breed unique hybrids and expand your Dragon City collection. You can also collect dragons from events in the game!\r\n\r\nFEATURES\r\n\r\n- Complete the Dragon Book! There are over 1000 awesome dragons to breed and collect to make your Dragon City grow!\r\n- New dragons join the game every week through breeding events and special islands.\r\n- Decorate your dragons with cool Dragon Skins from special events.\r\n- Adventure through the Dragon Quests and play against other Dragon Masters in the game’s PvP Arenas to collect one-of-a-kind dragons, claim Warrior’s Chests, and climb the leaderboards!\r\n- Summon dragons to your city from a magical world in the Tree Of Life and try their skills.\r\n- Collect Orbs and empower your dragons: See their strength in battle grow!\r\n- Unlock advanced game features like the Ancient World and build the Guardian Dragon Towers.\r\n- A social city! Join Alliances to battle with other Dragon Masters in Dragon City, chat with them, trade Orbs in the Trading Hub, share in Alliance Gift Events, and open Alliance Chests.\r\n\r\nThere are over 80 million Dragon Masters in Dragon City. What are you waiting for? Join the game and build your city today!\r\n\r\nIf you already love our game… Drop us a nice review :)\r\n\r\nDragon City is FREE to download and FREE to play. However, you can purchase in-app items with real money. If you wish to disable this feature of the game, please turn off the in-app purchases in your phone or tablet’s Settings.'),
('game006', 'Liên Quân', 'Garena Mobile', '0 ₫', '1. Chỉ cần 1 click để tải ngay game chiến thuật hàng đầu Việt Nam.\r\n2. Tải game và chiến hoàn toàn FREE\r\n\r\nTẢI FREE NGAY', 'Có gì mới?\r\n● Chuỗi sự kiện Moba Day 5v5 tặng tướng và trang phục miễn phí\r\n● Chế độ mới: Cup Vinh Quang - Tạo chiến đội, thi đấu và nhận quà\r\n● Cải tiến hệ thống nhận diện hành vi xấu\r\n● Tối ưu hiển thị trong trận đấu\r\n● Điều chỉnh cân bằng sức mạnh tướng, phù hiệu, phép bổ trợ và trang bị\r\n\r\nĐẤU TRƯỜNG HUYỀN THOẠI – THẮNG BẠI TẠI KỸ NĂNG!\r\nCùng sát cánh với liên minh của bạn trên đấu trường 5v5 hoàn toàn mới & FREE!\r\n\r\nGIỚI THIỆU\r\nHãy khẳng định bản thân, sát cánh đồng đội và thách đấu hàng triệu người chơi khác qua vô số những cuộc chiến 5v5 cực hay trên đấu trường huyền thoại MOBA Esports 5v5 của Garena Liên Quân Mobile – thắng bại tại kỹ năng!\r\nTham gia ngay vào những Liên Minh Clan trong trò chơi để cùng chiến đấu và trở thành huyền thoại trong game MOBA Esports PC nổi tiếng thế giới.\r\n\r\nHãy chọn ngay một biệt danh vừa chất vừa hay, gia nhập thế giới huyền thoại MOBA Esports 5v5 của Garena Liên Quân Mobile và khiến toàn bộ thế giới biết đến tên của bạn!\r\n\r\nTÍNH NĂNG\r\n\r\n1. Chế độ chơi đa dạng, thỏa sức chiến đấu\r\nBên cạnh bản đồ 5v5, người chơi có thể thỏa sức cùng bạn bè trải nghiệm các bản đồ tùy biến khác như 5v5 ngẫu nhiên, 3v3, 1v1, và những chế độ chơi đặc biệt cực hay & FREE liên tục được cập nhật siêu tốc như Garena Cờ Liên Quân/ Liên Quân chess thuộc dòng game auto chess đã được ra mắt\r\n\r\n2. Giao tranh liên tục, so tài kỹ năng\r\nChiến thắng dựa trên ba và chỉ ba yếu tố then chốt bảo đảm công bằng tuyệt đối đúng chất MOBA Esports: kỹ năng, đồng đội, và chiến thuật. Cùng chọn một Liên Minh trong game và nhanh tay chiến thôi nào. Let’s become legends by your skill!\r\n\r\n3. Chơi mọi lúc mọi nơi & hoàn toàn FREE\r\nTải game siêu tốc. Tìm trận và chiến trong chớp mắt. Có thể lựa chọn chiến trường 5v5 hoặc mode auto chess (Cờ Liên Quân) cực hấp dẫn. Chỉ 10 phút một trận, tha hồ thoải mái chơi Garena Liên Quân Mobile bất kỳ đâu, vào bất kỳ lúc nào, chiến Liên Quân siêu tốc đặc biệt hoàn toàn FREE!\r\n\r\n4. Thao tác đơn giản, dễ dàng làm quen\r\nHệ thống điều khiển tối giản đầy tinh tế gồm chỉ 2 ô phím ảo. Người chơi sẽ chỉ cần dùng 2 ngón tay, và dưới 5 giây trải nghiệm để sẵn sàng thách thức mọi cuộc chiến! Tốc độ siêu nhanh, dễ dàng điều khiển.\r\n\r\n5. Voice chat tiện dụng, giao tiếp dễ dàng\r\nHệ thống tích hợp voice chat thời gian thực, và bộ chat nhanh linh hoạt tùy biến theo ý muốn. Diễn biến trận đấu nhanh đến đâu, tốc độ giao tiếp sẽ càng nhanh & tiện lợi đến đấy. Nhớ dùng voice chat để giao tiếp với Liên Minh Clan của mình nhé.\r\n\r\n6. Cạnh tranh đấu hạng, thách thức đỉnh cao\r\nBang bang… Chỉ với vài phát súng ở cuối hiệp đã có thể phân định thắng bại. Hãy tham gia đấu hạng khốc liệt đầy tính MOBA Esports, thể hiện bản lĩnh trên Bảng xếp hạng huyền thoại của Garena Liên Quân Mobile. Tìm trận hạng siêu tốc, chiến Liên Quân siêu tốc.\r\n\r\n7. Tướng và trang phục hợp tác thương hiệu độc đáo chỉ có ở Garena Liên Quân Mobile\r\nHàng loạt tướng và trang phục chất đến từ những đối tác nổi tiếng: Superman, Batman, Wonder Woman, Joker,... đến từ DC Comic, Kirito và Asuna từ Sword Art Online, bộ trang phục Ultraman, Murad MTP thần tượng học đường... và hứa hẹn sẽ còn nhiều hơn trong tương lai!');

-- --------------------------------------------------------

--
-- Table structure for table `all_game_free`
--

CREATE TABLE `all_game_free` (
  `gameid` varchar(250) NOT NULL,
  `gamename` varchar(250) NOT NULL,
  `name_author` varchar(250) NOT NULL,
  `game_money` varchar(250) NOT NULL,
  `description` longtext NOT NULL,
  `description_extra` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `all_game_free`
--

INSERT INTO `all_game_free` (`gameid`, `gamename`, `name_author`, `game_money`, `description`, `description_extra`) VALUES
('game003', 'Angry Birds', 'Entertainment', '0 ₫', 'Tham gia cùng hàng trăm triệu người chơi MIỄN PHÍ và bắt đầu cuộc phiêu lưu thú vị với súng cao su ngay bây giờ! Lập nhóm với bạn bè của bạn, leo lên bảng xếp hạng, tập hợp trong gia tộc, thu thập mũ, tham gia các thử thách và chơi các sự kiện vui nhộn trong các chế độ chơi hoàn toàn mới. Phát triển nhóm của bạn và thể hiện kỹ năng của bạn trong trò chơi Angry Birds thú vị nhất hiện có!', '● THỬ THÁCH HÀNG NGÀY. Có một phút? Hoàn thành thử thách hàng ngày và kiếm một số phần thưởng nhanh chóng.\r\n● LÊN CẤP cho nhân vật của bạn bằng lông vũ và tăng sức mạnh ghi điểm của họ. Xây dựng đàn cuối cùng!\r\n● THAM GIA CLAN để hạ gục những con lợn với bạn bè và người chơi trên khắp thế giới.\r\n● CẠNH TRANH trong ARENA. Cạnh tranh với những người chơi khác để có một số niềm vui thả chim thân thiện và chứng minh ai là người giỏi nhất.\r\n● THU SILLY HATS. Thu thập những chiếc mũ với các chủ đề vui nhộn khác nhau để nâng cấp trò chơi thời trang cho đàn của bạn và tham gia các sự kiện đặc biệt.\r\n● HÃY ẤN TƯỢNG THE MIGHTY EAGLE trong những thử thách đặc biệt trong Mighty Eagle’s Bootcamp và kiếm tiền để sử dụng trong cửa hàng độc quyền của anh ấy.\r\n● RẤT NHIỀU MỨC. Chơi hàng trăm cấp độ với nhiều hơn được bổ sung trong các bản cập nhật thường xuyên và các sự kiện trong thời gian giới hạn.\r\n● BẢNG LÃNH ĐẠO. Cạnh tranh với bạn bè của bạn và những người chơi khác và chứng minh ai là người giỏi nhất trên bảng xếp hạng toàn cầu.\r\n● CHỌN CON CỦA BẠN. Chọn con chim nào để đưa vào súng cao su và đánh bại những con lợn bằng chiến lược!\r\n● MỨC NHIỀU GIAI ĐOẠN. Chơi các cấp độ thú vị, đầy thử thách với nhiều màn chơi - chỉ cần chú ý đến Boss Pigs!'),
('game004', 'Score 2', 'First Touch', '0 ₫', 'A NEW HERO! The brand new sequel to the award winning, chart topping, mobile smash hit!\r\n\r\nYou are unknown but your potential is extraordinary. You know your talents must be released for the world to see! Unleash your Hero on a glittering career by shooting, passing and scoring your way to superstardom!', 'Incredible graphics, showcasing glorious animations and hyper-realistic gameplay! Now with officially licensed, REAL clubs and leagues! Authentic kits and badges give the ultimate soccer experience! You will be at the heart of the action as you guide your Hero from hot prospect to global superstar!\r\n\r\nThis is a soccer sequel like no other for a game that is like no other!!!\r\n\r\nFEATURES\r\n• REVEL in an exciting new story following your Heros soccer career!\r\n• SCORE amazing goals, PICK out that killer pass and CURL your screaming shots into the top corner!\r\n• PACKED with over 90 officially licensed teams from some of the worlds greatest leagues! Who will you sign for?\r\n• ENHANCED graphics, ENRICHED motion-captured animations and with the same instantly recognisable \"pick-up and go\" gameplay\r\n• BRAND NEW Infinite Hero mode, How far will you go?\r\n• INSTANTLY RECOGNISABLE commentary from one of the worlds top commentators, ARLO WHITE!!\r\n• HAND-PICK your Heros unique look and customise his appearance.\r\n• TRIUMPH WITH TROPHIES as you progress through your career and unlock great prizes!\r\n• CONNECT to Facebook to sync your progress across devices\r\n\r\nTake your chances, score the goals, be the HERO!'),
('game006', 'Liên Quân', 'Garena Mobile', '0 ₫', '1. Chỉ cần 1 click để tải ngay game chiến thuật hàng đầu Việt Nam. 2. Tải game và chiến hoàn toàn FREE TẢI FREE NGAY', 'Có gì mới? ● Chuỗi sự kiện Moba Day 5v5 tặng tướng và trang phục miễn phí ● Chế độ mới: Cup Vinh Quang - Tạo chiến đội, thi đấu và nhận quà ● Cải tiến hệ thống nhận diện hành vi xấu ● Tối ưu hiển thị trong trận đấu ● Điều chỉnh cân bằng sức mạnh tướng, phù hiệu, phép bổ trợ và trang bị ĐẤU TRƯỜNG HUYỀN THOẠI – THẮNG BẠI TẠI KỸ NĂNG! Cùng sát cánh với liên minh của bạn trên đấu trường 5v5 hoàn toàn mới & FREE! GIỚI THIỆU Hãy khẳng định bản thân, sát cánh đồng đội và thách đấu hàng triệu người chơi khác qua vô số những cuộc chiến 5v5 cực hay trên đấu trường huyền thoại MOBA Esports 5v5 của Garena Liên Quân Mobile – thắng bại tại kỹ năng! Tham gia ngay vào những Liên Minh Clan trong trò chơi để cùng chiến đấu và trở thành huyền thoại trong game MOBA Esports PC nổi tiếng thế giới. Hãy chọn ngay một biệt danh vừa chất vừa hay, gia nhập thế giới huyền thoại MOBA Esports 5v5 của Garena Liên Quân Mobile và khiến toàn bộ thế giới biết đến tên của bạn! TÍNH NĂNG 1. Chế độ chơi đa dạng, thỏa sức chiến đấu Bên cạnh bản đồ 5v5, người chơi có thể thỏa sức cùng bạn bè trải nghiệm các bản đồ tùy biến khác như 5v5 ngẫu nhiên, 3v3, 1v1, và những chế độ chơi đặc biệt cực hay & FREE liên tục được cập nhật siêu tốc như Garena Cờ Liên Quân/ Liên Quân chess thuộc dòng game auto chess đã được ra mắt 2. Giao tranh liên tục, so tài kỹ năng Chiến thắng dựa trên ba và chỉ ba yếu tố then chốt bảo đảm công bằng tuyệt đối đúng chất MOBA Esports: kỹ năng, đồng đội, và chiến thuật. Cùng chọn một Liên Minh trong game và nhanh tay chiến thôi nào. Let’s become legends by your skill! 3. Chơi mọi lúc mọi nơi & hoàn toàn FREE Tải game siêu tốc. Tìm trận và chiến trong chớp mắt. Có thể lựa chọn chiến trường 5v5 hoặc mode auto chess (Cờ Liên Quân) cực hấp dẫn. Chỉ 10 phút một trận, tha hồ thoải mái chơi Garena Liên Quân Mobile bất kỳ đâu, vào bất kỳ lúc nào, chiến Liên Quân siêu tốc đặc biệt hoàn toàn FREE! 4. Thao tác đơn giản, dễ dàng làm quen Hệ thống điều khiển tối giản đầy tinh tế gồm chỉ 2 ô phím ảo. Người chơi sẽ chỉ cần dùng 2 ngón tay, và dưới 5 giây trải nghiệm để sẵn sàng thách thức mọi cuộc chiến! Tốc độ siêu nhanh, dễ dàng điều khiển. 5. Voice chat tiện dụng, giao tiếp dễ dàng Hệ thống tích hợp voice chat thời gian thực, và bộ chat nhanh linh hoạt tùy biến theo ý muốn. Diễn biến trận đấu nhanh đến đâu, tốc độ giao tiếp sẽ càng nhanh & tiện lợi đến đấy. Nhớ dùng voice chat để giao tiếp với Liên Minh Clan của mình nhé. 6. Cạnh tranh đấu hạng, thách thức đỉnh cao Bang bang… Chỉ với vài phát súng ở cuối hiệp đã có thể phân định thắng bại. Hãy tham gia đấu hạng khốc liệt đầy tính MOBA Esports, thể hiện bản lĩnh trên Bảng xếp hạng huyền thoại của Garena Liên Quân Mobile. Tìm trận hạng siêu tốc, chiến Liên Quân siêu tốc. 7. Tướng và trang phục hợp tác thương hiệu độc đáo chỉ có ở Garena Liên Quân Mobile Hàng loạt tướng và trang phục chất đến từ những đối tác nổi tiếng: Superman, Batman, Wonder Woman, Joker,... đến từ DC Comic, Kirito và Asuna từ Sword Art Online, bộ trang phục Ultraman, Murad MTP thần tượng học đường... và hứa hẹn sẽ còn nhiều hơn trong tương lai!');

-- --------------------------------------------------------

--
-- Table structure for table `all_game_not_free`
--

CREATE TABLE `all_game_not_free` (
  `gameid` varchar(250) NOT NULL,
  `gamename` varchar(250) NOT NULL,
  `name_author` varchar(250) NOT NULL,
  `game_money` varchar(250) NOT NULL,
  `description` longtext NOT NULL,
  `description_extra` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `all_game_not_free`
--

INSERT INTO `all_game_not_free` (`gameid`, `gamename`, `name_author`, `game_money`, `description`, `description_extra`) VALUES
('game001', 'Genshin Impact-S.PAY', 'MiHoYo Limited', '10.000 ₫', 'Lục địa Teyvat rộng lớn, nơi vô số sinh vật sinh sôi và hội tụ. Đấy là thế giới do bảy vị Thần thống trị, cũng là nơi bảy loại nguyên tố tụ hội...', 'Dưới bầu trời xa lạ, có người thiếu niên và thiếu nữ đang đứng trong gió bụi. Các bạn chính là cặp song sinh đến từ vùng đất xa lạ. Người thân của bạn bị vị Thần lạ mặt bắt đi, và bạn cũng bị Thần phong ấn chìm vào giấc ngủ sâu... Genshin Impact là một game nhập vai phiêu lưu thế giới mở mới được phát triển bởi miHoYo. Bạn sẽ khám phá một thế giới giả tưởng có tên là \"Lục địa Teyvat\" trong trò chơi. Trong thế giới rộng lớn này, bạn có thể du hành qua bảy vương quốc, gặp gỡ những người bạn đồng hành với những tính cách và năng lực độc đáo khác nhau, cùng chiến đấu chống lại kẻ thù mạnh và bước vào con đường tìm kiếm người thân, hoặc bạn có thể đi lang thang không mục đích và đắm mình trong một thế giới đầy sức sống. Hãy để sự tò mò thúc đẩy bản thân khám phá mọi bí mật trong thế giới này nào... Cho đến khi bạn đoàn tụ với người thân và chứng kiến sự lắng đọng của mọi thứ ở điểm đến cuối cùng. 〓Thế giới mở, tự do khám phá〓 Genshin Impact là một game nhập vai phiêu lưu thế giới mở, chỉ cần bạn sử dụng thể lực hợp lý, thì sẽ có thể chu du đến mọi vùng núi cao biển rộng, khám phá những cảnh vật kỳ bí. Hãy cùng nhau thám hiểm xem sẽ có những gì đang đợi bạn phía trước nào! 〓Phản ứng nguyên tố, chiến đấu chiến lược〓 Thế giới trong game được hình thành bởi bảy loại nguyên tố: Phong, Lôi, Thủy, Hỏa, Băng, Thảo, Nham. Nhân vật có Vision sẽ có thể dùng sức mạnh của nguyên tố để chiến đấu và thám hiểm. Thủy gặp Hỏa sẽ bốc hơi, Hỏa gặp Lôi sẽ quá tải, Lôi gặp Thủy sẽ nhiễm điện... Đối mặt với kẻ địch khác nhau, có thể dùng kỹ năng khác nhau để kích hoạt nguyên tố khắc chế giành chiến thắng. 〓Đồ họa và âm nhạc chất lượng cao〓 Genshin Impact có phong cách nghệ thuật mới mẻ, chuyển động của nhân vật được thực hiện thông qua việc nắm bắt cử động và điều chỉnh chi tiết, mang đến hiệu ứng trình diễn chất lượng cao. Ngày đêm thay đổi 24 giờ, thời tiết và âm nhạc cũng thay đổi linh hoạt, dù bạn ở đâu, bạn cũng sẽ luôn nghe thấy những màn trình diễn đặc trưng của dàn nhạc giao hưởng hàng đầu thế giới như London Philharmonic Orchestra và Shanghai Symphony Orchestra. 〓Tập hợp đồng đội, cùng nhau thám hiểm Trong quá trình thám hiểm, còn có thể kết giao được với những đồng đội có khả năng đặc biệt, hãy thử kết hợp đội hình mạnh nhất, thu thập nguyên liệu cường hóa nhân vật để chinh phục bí cảnh nào. Rất nhiều điều mới mẻ đang chờ bạn khám phá, cùng bắt đầu thôi nào. Genshin Impact khu vực Việt Nam được phát hành độc quyền bởi Công ty cổ phần dịch vụ S.PAY Việt Nam.'),
('game002', 'Golf', 'Haegin Co., Ltd.', '5.000 ₫', 'Enough with the boring golf games! Time for some thrilling excitement without the wait!\r\nEnjoy the fast and easy golf battle with maximum of 8 players! Are you ready to hit the green at EXTREME GOLF?', '● Real-time Multiplayer Golf Battle - A fast-paced real-time round of golf where you dont have to wait for others! - Hit the green with golfers around the world through instant matchmaking! - Rise up the ranks and become the king of golf! ● Simple Controls! Nothing could be easier! Easy and swift matches! - Aim! Swing! Its that easy! Find the optimal direction and power. Then, simply pull and let go and to land your ball on the fairway! - Golf and life is all about the timing! Pull and let go at the perfect timing for the perfect putt. - Dont worry if you are new to golf. With these simple controls, hitting a Birdie, Albatross, or a Hole-In-One wont only be a dream! ● Golf clubs and balls are your best friends on the field! - Drivers, Woods, Long Irons, Short Irons, Rough Irons, Wedges, Sand Wedges, and Putters. Weve got everything you need! - Master the beautiful Courses with various Clubs and unique Balls! - Build your very own Club by upgrading its Power, Accuracy, Top Spin, Back Spin, etc.! - Improve your Club to perfection through Club Fitting!'),
('game005', 'Dragon City', 'Socialpoint', '1.000 ₫', 'Ready to take on the hottest dragon game and collect and breed tons of adorable fire-breathing dragons? Train them to your will, grow your collection, build your city, and prove your might to be the top Dragon Master in the world!\r\n\r\n', 'Build a Dragon City on floating islands, fill it with farms, habitats, buildings…and tons of dragons! Breed cute, baby dragons, treat them well and build farms to feed and evolve them into stunning monsters to expand your collection and battle them in the game’s PvP Arenas! Join forces with other Dragon Masters in the game by joining an Alliance! Interact in the chat, participate in Alliance events, trade Orbs, and unlock special rewards. Combine dragons of Fire, Nature, Pure, Legend, and many other elements, to breed unique hybrids and expand your Dragon City collection. You can also collect dragons from events in the game! FEATURES - Complete the Dragon Book! There are over 1000 awesome dragons to breed and collect to make your Dragon City grow! - New dragons join the game every week through breeding events and special islands. - Decorate your dragons with cool Dragon Skins from special events. - Adventure through the Dragon Quests and play against other Dragon Masters in the game’s PvP Arenas to collect one-of-a-kind dragons, claim Warrior’s Chests, and climb the leaderboards! - Summon dragons to your city from a magical world in the Tree Of Life and try their skills. - Collect Orbs and empower your dragons: See their strength in battle grow! - Unlock advanced game features like the Ancient World and build the Guardian Dragon Towers. - A social city! Join Alliances to battle with other Dragon Masters in Dragon City, chat with them, trade Orbs in the Trading Hub, share in Alliance Gift Events, and open Alliance Chests. There are over 80 million Dragon Masters in Dragon City. What are you waiting for? Join the game and build your city today! If you already love our game… Drop us a nice review :) Dragon City is FREE to download and FREE to play. However, you can purchase in-app items with real money. If you wish to disable this feature of the game, please turn off the in-app purchases in your phone or tablet’s Settings.');

-- --------------------------------------------------------

--
-- Table structure for table `all_movie`
--

CREATE TABLE `all_movie` (
  `movie_id` varchar(250) NOT NULL,
  `movie_name` varchar(250) NOT NULL,
  `movie_author` varchar(250) NOT NULL,
  `movie_money` varchar(250) NOT NULL,
  `movie_description` longtext NOT NULL,
  `movie_description_extra` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `all_movie`
--

INSERT INTO `all_movie` (`movie_id`, `movie_name`, `movie_author`, `movie_money`, `movie_description`, `movie_description_extra`) VALUES
('movie001', 'Sonic', 'Hoạt hình', '0 ₫', 'Thế giới cần một anh hùng, chúng ta có một chú nhím. Sở hữu năng lực siêu tốc độ, Nhím Sonic (do Ben Schwartz lồng tiếng), còn gọi là Chú Quỷ Xanh, đến ngôi nhà mới trên Trái đất. Đó là khi chú vô tình khiến cả một vùng rộng lớn bị mất điện và gây chú ý cho thần ác siêu bựa Tiến sĩ Robotnik (do Jim Carrey thủ vai). Và giờ là cuộc đua tổng lực trên toàn cầu giữa siêu phản diện và siêu tốc độ để ngăn chặn Robotnik sử dụng năng lực vô song của Sonic để thống trị thế giới. Sonic hợp tác với Chúa tể bánh Rán, còn được biết đến với biệt danh Cảnh sát trưởng Tom Wachowski (James Marsden), để giải cứu hành tinh. Bộ phim hài phiêu lưu do người đóng này sẽ mang đến niềm vui cho cả gia đình.\r\n', 'James Marsden, Tika Sumpter, Jim Carrey, Ben Schwartz\r\n					\r\n							Nhà sản xuất\r\n						\r\n								Neal H. Moritz, Toby Ascher, Toru Nakahara, Takeshi Ito, Hajime Satomi, Haruki Satomi, Masanao Maeda, Nan Morales, Tim Miller\r\n						\r\n							Đạo diễn\r\n					\r\n								Jeff Fowler\r\n				\r\n							Biên kịch\r\n						\r\n								Pat Casey, Josh Miller'),
('movie002', 'Godzilla', 'Kinh Dị', '60.000 ₫', '	The story follows the heroic efforts of the crypto-zoological agency Monarch as its members face off against a battery of god-sized monsters, including the mighty Godzilla, who collides with Mothra, Rodan, and his ultimate nemesis, the three-headed King Ghidorah. When these ancient super-species—thought to be mere myths—rise again, they all vie for supremacy, leaving humanity’s very existence hanging in the balance.\r\n', 'Aisha Hinds, Bradley Whitford, Charles Dance, David Strathairn, Ken Watanabe, Kyle Chandler, Millie Bobby Brown, O\'Shea Jackson Jr., Sally Hawkins, Thomas Middleditch, Vera Farmiga, Ziyi Zhang\r\n						\r\n							Nhà sản xuất\r\n					\r\n								Max Borenstein, Michael Dougherty, Zach Shields\r\n					\r\n							Đạo diễn\r\n					\r\n								Michael Dougherty\r\n					\r\n							Biên kịch\r\n						\r\n								Alex Garcia, Brian Rogers, Jon Jashni, Mary Parent, Thomas Tull'),
('movie003', 'Rampage', 'Hành Động', '0 ₫', 'Primatologist Davis (Dwayne Johnson) shares an unshakable bond with George, the extraordinarily intelligent, silverback gorilla who has been in his care since birth. When a greed-fueled corporation\'s genetic experiment goes awry, George and other animals across the country are mutated into aggressive super creatures that rampage the city. In an adrenaline-filled ride, Davis tries to find an antidote to not only halt a global catastrophe, but to also save the fearsome creature that was once his friend.\r\n		', 'Diễn viên\r\n						\r\n								Breanne Hill, Demetrius Grosse, Dwayne, \"The Rock\", Johnson, Dwayne Johnson, Jack Quaid, Jake Lacy, Jason Liles, Jeffrey Dean Morgan, Joe Manganiello, Malin Akerman, Marley Shelton, Matt Gerald, Naomie Harris, P.J. Byrne\r\n						\r\n							Nhà sản xuất\r\n							Adam Sztykiel, Carlton Cuse, Ryan Condal, Ryan Engle\r\n							\r\n							Đạo diễn\r\n							Brad Peyton\r\n					\r\n							Biên kịch\r\n						    Beau Flynn, Brad Peyton, Hiram Garcia, John Rickard'),
('movie004', 'Mulan', 'Phiêu Lưu', '10.000 ₫', '	Acclaimed filmmaker Niki Caro brings the epic tale of China\'s legendary warrior to life in Disney\'s MULAN, in which a fearless young woman risks everything out of love for her family and her country to become one of the greatest warriors China has ever known. When the Emperor of China issues a decree that one man per family must serve in the Imperial Army to defend the country from Northern invaders, Hua Mulan, the eldest daughter of an honored warrior, steps in to take the place of her ailing father.\r\n			', 'Diễn viên\r\n                            Yifei Liu, Donnie Yen, Gong Li, Jet Li, Jason Scott Lee, Yoson An, Tzi Ma, Rosalind Chao, Cheng Pei Pei, Xana Tang, Ron Yuan, Jun Yu, Chen Tang, Doua Moua, Jimmy Wong, Nelson Lee, Hoon Lee, Crystal Rao, Elena Askin, Vincent Feng, RJ O\'Young, Roger Yuan, Jenson Cheng, Arka Das, Ming-Na Wen, Jen Kuo Sung, King Lau, Zhaidarbek Kunguzhinov, Gary Young, Wolf Chen, Owen Kwong, Jo Lo, Heidi Chen, Michael Chun Long Yip, Peter Qi, Jia Yang, Dante Pang, Young-H Lee, Elizabeth Quan Shang, Mary Wong, Audrey Chan, Jasmin Zhou, K. Y. Chan, David T. Lim.\r\n							\r\n							Nhà sản xuất\r\n							Chris Bender, Jake Weiner, Jason T. Reed\r\n						\r\n							Đạo diễn\r\n							Niki Caro\r\n							\r\n							Biên kịch\r\n							Rick Jaffa, Amanda Silver, Lauren Hynek, Elizabeth Martin'),
('movie005', 'Tenet', 'Hành Động', '45.000 ₫', 'Armed with only one word—Tenet—and fighting for the survival of the entire world, the Protagonist journeys through a twilight world of international espionage on a mission that will unfold in something beyond real time.\r\n		', '		Diễn viên\r\n						John David Washington, Robert Pattinson, Elizabeth Debicki, Dimple Kapadia, Michael Caine, Kenneth Branagh\r\n						\r\n							Nhà sản xuất\r\n							Emma Thomas, Christopher Nolan\r\n							\r\n							Đạo diễn\r\n							Christopher Nolan\r\n						\r\n							Biên kịch\r\n							Christopher Nolan'),
('movie006', 'Soul', 'Hành Động', '40.000 ₫', 'What is it that makes you...YOU? Pixar Animation Studios\' all-new feature film SOUL introduces Joe Gardner (voice of Jamie Foxx) – a middle-school band teacher who gets the chance of a lifetime to play at the best jazz club in town. But one small misstep takes him from the streets of New York City to The Great Before – a fantastical place where new souls get their personalities, quirks and interests before they go to Earth.\r\n		', '	Diễn viên\r\n							Jamie Foxx, Tina Fey, Angela Bassett, Ahmir-Khalib \"Questlove\" Thompson, Phylicia Rashad, Daveed Diggs, Graham Norton, Rachel House, Alice Braga, Richard Ayoade, Donnell Rawlings, Cora Champommier, Margo Hall, Rhodessa Jones, Wes Studi, Sakina Jaffrey, Fortune Feimster, Calum Grant, Laura Mooney, Peggy Flood, Zenobia Shroff, June Squibb, Ochuwa Oghie, Jeannie Tirado, Catherine Cavadini, Dorian Lockett, Doris Burke, Ronnie Del Carmen, Esther K. Chae, Elisapie Isaac, Marcus Shelby.\r\n						\r\n							Nhà sản xuất\r\n							Dana Murray\r\n						\r\n							Đạo diễn\r\n							Pete Docter, Kemp Powers\r\n						\r\n							Biên kịch\r\n							Pete Docter, Mike Jones\r\n							');

-- --------------------------------------------------------

--
-- Table structure for table `all_movie_free`
--

CREATE TABLE `all_movie_free` (
  `movie_id` varchar(250) NOT NULL,
  `movie_name` varchar(250) NOT NULL,
  `movie_author` varchar(250) NOT NULL,
  `movie_money` varchar(250) NOT NULL,
  `movie_description` longtext NOT NULL,
  `movie_description_extra` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `all_movie_free`
--

INSERT INTO `all_movie_free` (`movie_id`, `movie_name`, `movie_author`, `movie_money`, `movie_description`, `movie_description_extra`) VALUES
('movie001', 'Sonic', 'Hoạt hình', '0 ₫', 'Thế giới cần một anh hùng, chúng ta có một chú nhím. Sở hữu năng lực siêu tốc độ, Nhím Sonic (do Ben Schwartz lồng tiếng), còn gọi là Chú Quỷ Xanh, đến ngôi nhà mới trên Trái đất. Đó là khi chú vô tình khiến cả một vùng rộng lớn bị mất điện và gây chú ý cho thần ác siêu bựa Tiến sĩ Robotnik (do Jim Carrey thủ vai). Và giờ là cuộc đua tổng lực trên toàn cầu giữa siêu phản diện và siêu tốc độ để ngăn chặn Robotnik sử dụng năng lực vô song của Sonic để thống trị thế giới. Sonic hợp tác với Chúa tể bánh Rán, còn được biết đến với biệt danh Cảnh sát trưởng Tom Wachowski (James Marsden), để giải cứu hành tinh. Bộ phim hài phiêu lưu do người đóng này sẽ mang đến niềm vui cho cả gia đình.\r\n', 'James Marsden, Tika Sumpter, Jim Carrey, Ben Schwartz\r\n					\r\n							Nhà sản xuất\r\n						\r\n								Neal H. Moritz, Toby Ascher, Toru Nakahara, Takeshi Ito, Hajime Satomi, Haruki Satomi, Masanao Maeda, Nan Morales, Tim Miller\r\n						\r\n							Đạo diễn\r\n					\r\n								Jeff Fowler\r\n				\r\n							Biên kịch\r\n						\r\n								Pat Casey, Josh Miller'),
('movie003', 'Rampage', 'Hành Động', '0 ₫', 'Primatologist Davis (Dwayne Johnson) shares an unshakable bond with George, the extraordinarily intelligent, silverback gorilla who has been in his care since birth. When a greed-fueled corporation\'s genetic experiment goes awry, George and other animals across the country are mutated into aggressive super creatures that rampage the city. In an adrenaline-filled ride, Davis tries to find an antidote to not only halt a global catastrophe, but to also save the fearsome creature that was once his friend.', 'Diễn viên\r\n						\r\n								Breanne Hill, Demetrius Grosse, Dwayne, \"The Rock\", Johnson, Dwayne Johnson, Jack Quaid, Jake Lacy, Jason Liles, Jeffrey Dean Morgan, Joe Manganiello, Malin Akerman, Marley Shelton, Matt Gerald, Naomie Harris, P.J. Byrne\r\n						\r\n							Nhà sản xuất\r\n							Adam Sztykiel, Carlton Cuse, Ryan Condal, Ryan Engle\r\n							\r\n							Đạo diễn\r\n							Brad Peyton\r\n					\r\n							Biên kịch\r\n						    Beau Flynn, Brad Peyton, Hiram Garcia, John Rickard');

-- --------------------------------------------------------

--
-- Table structure for table `all_movie_not_free`
--

CREATE TABLE `all_movie_not_free` (
  `movie_id` varchar(250) NOT NULL,
  `movie_name` varchar(250) NOT NULL,
  `movie_author` varchar(250) NOT NULL,
  `movie_money` varchar(250) NOT NULL,
  `movie_description` longtext NOT NULL,
  `movie_description_extra` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `all_movie_not_free`
--

INSERT INTO `all_movie_not_free` (`movie_id`, `movie_name`, `movie_author`, `movie_money`, `movie_description`, `movie_description_extra`) VALUES
('movie002', 'Godzilla', 'Kinh Dị', '60.000 ₫', 'The story follows the heroic efforts of the crypto-zoological agency Monarch as its members face off against a battery of god-sized monsters, including the mighty Godzilla, who collides with Mothra, Rodan, and his ultimate nemesis, the three-headed King Ghidorah. When these ancient super-species—thought to be mere myths—rise again, they all vie for supremacy, leaving humanity’s very existence hanging in the balance.\r\n', 'Aisha Hinds, Bradley Whitford, Charles Dance, David Strathairn, Ken Watanabe, Kyle Chandler, Millie Bobby Brown, O\'Shea Jackson Jr., Sally Hawkins, Thomas Middleditch, Vera Farmiga, Ziyi Zhang\r\n						\r\n							Nhà sản xuất\r\n					\r\n								Max Borenstein, Michael Dougherty, Zach Shields\r\n					\r\n							Đạo diễn\r\n					\r\n								Michael Dougherty\r\n					\r\n							Biên kịch\r\n						\r\n								Alex Garcia, Brian Rogers, Jon Jashni, Mary Parent, Thomas Tull'),
('movie004', 'Mulan', 'Phiêu Lưu', '10.000 ₫', 'Acclaimed filmmaker Niki Caro brings the epic tale of China\'s legendary warrior to life in Disney\'s MULAN, in which a fearless young woman risks everything out of love for her family and her country to become one of the greatest warriors China has ever known. When the Emperor of China issues a decree that one man per family must serve in the Imperial Army to defend the country from Northern invaders, Hua Mulan, the eldest daughter of an honored warrior, steps in to take the place of her ailing father.\r\n		', 'Diễn viên\r\n                            Yifei Liu, Donnie Yen, Gong Li, Jet Li, Jason Scott Lee, Yoson An, Tzi Ma, Rosalind Chao, Cheng Pei Pei, Xana Tang, Ron Yuan, Jun Yu, Chen Tang, Doua Moua, Jimmy Wong, Nelson Lee, Hoon Lee, Crystal Rao, Elena Askin, Vincent Feng, RJ O\'Young, Roger Yuan, Jenson Cheng, Arka Das, Ming-Na Wen, Jen Kuo Sung, King Lau, Zhaidarbek Kunguzhinov, Gary Young, Wolf Chen, Owen Kwong, Jo Lo, Heidi Chen, Michael Chun Long Yip, Peter Qi, Jia Yang, Dante Pang, Young-H Lee, Elizabeth Quan Shang, Mary Wong, Audrey Chan, Jasmin Zhou, K. Y. Chan, David T. Lim.\r\n							\r\n							Nhà sản xuất\r\n							Chris Bender, Jake Weiner, Jason T. Reed\r\n						\r\n							Đạo diễn\r\n							Niki Caro\r\n							\r\n							Biên kịch\r\n							Rick Jaffa, Amanda Silver, Lauren Hynek, Elizabeth Martin'),
('movie005', 'Tenet', 'Hành Động', '45.000 ₫', 'Armed with only one word—Tenet—and fighting for the survival of the entire world, the Protagonist journeys through a twilight world of international espionage on a mission that will unfold in something beyond real time.', 'Diễn viên\r\n						John David Washington, Robert Pattinson, Elizabeth Debicki, Dimple Kapadia, Michael Caine, Kenneth Branagh\r\n						\r\n							Nhà sản xuất\r\n							Emma Thomas, Christopher Nolan\r\n							\r\n							Đạo diễn\r\n							Christopher Nolan\r\n						\r\n							Biên kịch\r\n							Christopher Nolan'),
('movie006', 'Soul', 'Hành Động', '40.000 ₫', 'What is it that makes you...YOU? Pixar Animation Studios\' all-new feature film SOUL introduces Joe Gardner (voice of Jamie Foxx) – a middle-school band teacher who gets the chance of a lifetime to play at the best jazz club in town. But one small misstep takes him from the streets of New York City to The Great Before – a fantastical place where new souls get their personalities, quirks and interests before they go to Earth.', 'Diễn viên\r\n							Jamie Foxx, Tina Fey, Angela Bassett, Ahmir-Khalib \"Questlove\" Thompson, Phylicia Rashad, Daveed Diggs, Graham Norton, Rachel House, Alice Braga, Richard Ayoade, Donnell Rawlings, Cora Champommier, Margo Hall, Rhodessa Jones, Wes Studi, Sakina Jaffrey, Fortune Feimster, Calum Grant, Laura Mooney, Peggy Flood, Zenobia Shroff, June Squibb, Ochuwa Oghie, Jeannie Tirado, Catherine Cavadini, Dorian Lockett, Doris Burke, Ronnie Del Carmen, Esther K. Chae, Elisapie Isaac, Marcus Shelby.\r\n						\r\n							Nhà sản xuất\r\n							Dana Murray\r\n						\r\n							Đạo diễn\r\n							Pete Docter, Kemp Powers\r\n						\r\n							Biên kịch\r\n							Pete Docter, Mike Jones');

-- --------------------------------------------------------

--
-- Table structure for table `reset_token`
--

CREATE TABLE `reset_token` (
  `email` varchar(250) NOT NULL,
  `token` varchar(250) NOT NULL,
  `esp` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reset_token`
--

INSERT INTO `reset_token` (`email`, `token`, `esp`) VALUES
('quynhanhaww@gmail.com', 'c13257c83c35e1ee193c46fa3b17e5ee', 1620894699);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `all_game`
--
ALTER TABLE `all_game`
  ADD PRIMARY KEY (`gameid`);

--
-- Indexes for table `all_game_free`
--
ALTER TABLE `all_game_free`
  ADD PRIMARY KEY (`gameid`);

--
-- Indexes for table `all_game_not_free`
--
ALTER TABLE `all_game_not_free`
  ADD PRIMARY KEY (`gameid`);

--
-- Indexes for table `all_movie`
--
ALTER TABLE `all_movie`
  ADD PRIMARY KEY (`movie_id`);

--
-- Indexes for table `all_movie_free`
--
ALTER TABLE `all_movie_free`
  ADD PRIMARY KEY (`movie_id`);

--
-- Indexes for table `all_movie_not_free`
--
ALTER TABLE `all_movie_not_free`
  ADD PRIMARY KEY (`movie_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
