
function show_pass() {
  let pasBox= document.getElementById("password");
  let passBox = document.getElementById("check_password");
  if ((pasBox.type === "password") || (passBox.type === "password") || (passBox.type === "password" && pasBox.type === "password" )) {
    pasBox.type = "text";
    passBox.type = "text";
  }
  else {
    pasBox.type = "password";
    passBox.type ="password";
  }
}